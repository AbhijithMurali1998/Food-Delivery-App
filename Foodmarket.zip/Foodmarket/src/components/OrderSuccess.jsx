import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./OrderSuccess.css";

const OrderSuccess = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();

  const [status, setStatus] = useState("pending");
  const [notified, setNotified] = useState(false);

  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`http://localhost:3001/api/admin/orders/${orderId}`);
        if (!res.ok) throw new Error("Failed to fetch order");
        const data = await res.json();

        setStatus(data.status);

        // Show popup when admin accepts the order
        if (data.status === "accepted" && !notified) {
          alert("✅ Your order has been accepted! It will arrive soon.");
          setNotified(true);
        }
      } catch (err) {
        console.error("Polling error:", err.message);
      }
    }, 4000); // every 4 seconds

    return () => clearInterval(interval); // cleanup
  }, [orderId, notified]);

 const handleConfirm = async () => {
  try {
    const res = await fetch(
      `http://localhost:3001/api/orders/${orderId}/deliver`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
          // If your backend requires token: 
          // Authorization: `Bearer ${localStorage.getItem("userToken")}`
        }
      }
    );

    if (!res.ok) throw new Error("Failed to confirm delivery");

    alert("✅ Thank you! We've received your confirmation.");
    navigate("/"); // redirect after confirmation
  } catch (err) {
    console.error("❌ Confirm Error:", err);
    alert("Failed to confirm. Please try again.");
  }
};


  return (
    <div className="order-success">
      <h2>🎉 Order Placed Successfully!</h2>
      <p>Order ID: <strong>{orderId}</strong></p>
      <p>Current Status: <strong>{status}</strong></p>

      <p>Please confirm after receiving your food:</p>
      <button onClick={handleConfirm}>I Received My Food</button>
    </div>
  );
};

export default OrderSuccess;
