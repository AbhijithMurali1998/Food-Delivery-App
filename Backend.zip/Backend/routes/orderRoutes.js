// routes/orderRoutes.js
import express from "express";
import Order from "../models/Order.js";

const router = express.Router();

// ✅ Route to place a new order
router.post("/orders/place", async (req, res) => {
  try {
    const { customer, items, total, paymentMethod } = req.body;

    if (!customer || !items || !total || !paymentMethod) {
      return res.status(400).json({ error: "Missing order fields" });
    }

    const newOrder = await Order.create({
      customer,
      items,
      total,
      paymentMethod,
      status: "pending", // default
      createdAt: new Date(),
    });

    res.status(201).json({ orderId: newOrder._id });
  } catch (error) {
    console.error("❌ Order error:", error.message);
    res.status(500).json({ error: "Failed to place order" });
  }
});

// ✅ Route for user to confirm delivery
router.post("/orders/:id/deliver", async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status: "delivered" },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({ message: "Order marked as delivered", order });
  } catch (error) {
    console.error("❌ Delivery confirm error:", error.message);
    res.status(500).json({ error: "Failed to update order" });
  }
});

export default router;
