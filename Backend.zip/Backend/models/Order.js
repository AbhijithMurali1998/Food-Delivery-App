import mongoose from "mongoose";

const orderSchema = new mongoose.Schema(
  {
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User", // 🔗 Reference to User model
      required: true,
    },
    customerDetails: {
      name: String,
      address: String,
      phone: String,
    },
    items: [
      {
        id: String,
        name: String,
        price: Number,
        quantity: Number,
      },
    ],
    total: Number,
    paymentMethod: String,
    status: {
      type: String,
      default: "pending", // admin actions depend on this
    },
  },
  {
    timestamps: true, // Adds createdAt and updatedAt
  }
);

const Order = mongoose.model("Order", orderSchema);

export default Order; fix 